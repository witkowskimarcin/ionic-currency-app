import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ModalController } from '@ionic/angular';
import { HttpClient } from '@angular/common/http';
import { map } from "rxjs/operators";
@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss']
})
export class Tab2Page {

  information: any[];
  automaticClose = false;
  money_tab = [
    'EUR',
    'BGN',
    'NZD',
    'ILS',
    'RUB',
    'CAD',
    'USD',
    'PHP',
    'CHF',
    'ZAR',
    'AUD',
    'JPY',
    'TRY',
    'HKD',
    'MYR',
    'THB',
    'HRK',
    'NOK',
    'IDR',
    'DKK',
    'CZK',
    'HUF',
    'GBP',
    'MXN',
    'KRW',
    'ISK',
    'SGD',
    'BRL',
    'PLN',
    'INR',
    'RON',
    'CNY',
    'SEK'];
    Money_first = 'EUR';
    Money_second = 'USD';
    hideMe = true;
    hideMe_1 = false;
    hideMe_2 = false;
    rates: any [] ;

  constructor(private http: HttpClient){

      this.http.get('https://api.exchangeratesapi.io/latest').subscribe(res =>{
      this.information = res['rates'];
      //console.log(this.information["BGN"]);
      // for(var i = 0;i<3;i++)
      // {
      //   console.log(this.information['BGN']);
      // }
      //console.log(res);
      for (let entry of this.money_tab) {
        console.log(this.information[entry]); // 1, "string", false
      }
      this.course = this.information[this.Money_second];
      //this.information[0].open = true;
      //console.log(this.information[0]);
      });


      //console.log(this.http.get('https://api.exchangeratesapi.io/latest'));

      this.http.get('https://api.exchangeratesapi.io/history?start_at=2017-02-01&end_at=2018-02-01&base=EUR&symbols=PLN').subscribe(res =>{
        this.rates = res['rates'];
         console.log("TUTAJ!!!!!")
         // console.log(res);
         console.log(this.rates);
 
         console.log("Tutaj0");

         let parameters = new Map<string, string>();
   Object.keys(this.rates).forEach(key => {
     console.log("Tutaj1");
     let k = new Date(key);
     let k2 = [k.getFullYear(), k.getMonth() + 1, k.getDate()].join('/');
     //let k = JSON.stringify(key);
     console.log("Tutaj2");
     let v = this.rates[key].PLN;
     console.log(this.rates[key].PLN);
    //  console.log(k);
    //  console.log(k);
    //  console.log(k);
    //  console.log(k);
    //  console.log(k);
    //  console.log(v);
    //  console.log(v);
    //  console.log(v);
    //  console.log(v);
    //  console.log(v);
    //  console.log(v);
    //  console.log(v);
 
     this.data1.push(this.dosome(k2,v));
 
         // rates.forEach((value: string, key) => {
         //   //this.rates1.push(value)
         //   console.log("TUTAJ!!!!!")
         //   console.log(value)
         //   console.log(key)
         // });
         
       });


    
    //console.log(this.data1[0]);
});

      // for (let i = 0; i < 1000; i++) {
      //   this.data1.push(this.dosome("date"+i,i));
      

      // }


  }
//
  oldvalue: number = 0;
  course = 2.44;
  resolts = 0;
  toggleSection_1(index)
  {
    
    this.http.get('https://api.exchangeratesapi.io/latest?base='+index).subscribe(res =>{
      this.information = res['rates'];
      console.log(res);
      this.Money_first = index;
      this.course = this.information[this.Money_second];  
    });
    this.hideMe_1 = !this.hideMe_1;
    
   // console.log(index);
  }

  toggleSection_2(index)
  {
    this.Money_second = index;
    this.course = this.information[this.Money_second];
    this.hideMe_2 = !this.hideMe_2;
  }

  toggleItem(index, childIndex)
  {
    //this.information[index].children[childIndex].open = !this.information[index].children[childIndex].open;

  }



  hide_1() {
    this.hideMe_1 = !this.hideMe_1;
  }
  hide_2() {
    this.hideMe_2 = !this.hideMe_2;
  }
  Getvalue() {
    this.resolts = this.oldvalue * this.course;
  }

  public lineChartData:Array<any> = [
  {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
  {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'},
  {data: [18, 48, 77, 9, 100, 27, 40], label: 'Series C'}
];
public lineChartLabels:Array<any> = ['January', 'February', 'March', 'April', 'May', 'June', 'July'];
public lineChartOptions:any = {
  responsive: true
};
public lineChartColors:Array<any> = [
  { // grey
    backgroundColor: 'rgba(148,159,177,0.2)',
    borderColor: 'rgba(148,159,177,1)',
    pointBackgroundColor: 'rgba(148,159,177,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(148,159,177,0.8)'
  },
  { // dark grey
    backgroundColor: 'rgba(77,83,96,0.2)',
    borderColor: 'rgba(77,83,96,1)',
    pointBackgroundColor: 'rgba(77,83,96,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(77,83,96,1)'
  },
  { // grey
    backgroundColor: 'rgba(148,159,177,0.2)',
    borderColor: 'rgba(148,159,177,1)',
    pointBackgroundColor: 'rgba(148,159,177,1)',
    pointBorderColor: '#fff',
    pointHoverBackgroundColor: '#fff',
    pointHoverBorderColor: 'rgba(148,159,177,0.8)'
  }
];
public lineChartLegend:boolean = true;
public lineChartType:string = 'line';

public randomize():void {
  let _lineChartData:Array<any> = new Array(this.lineChartData.length);
  for (let i = 0; i < this.lineChartData.length; i++) {
    _lineChartData[i] = {data: new Array(this.lineChartData[i].data.length), label: this.lineChartData[i].label};
    for (let j = 0; j < this.lineChartData[i].data.length; j++) {
      _lineChartData[i].data[j] = Math.floor((Math.random() * 100) + 1);
    }
  }
  this.lineChartData = _lineChartData;
}

// events
public chartClicked(e:any):void {
  console.log(e);
}

public chartHovered(e:any):void {
  console.log(e);
}

// charts
private static oneDay = 24 * 3600 * 1000;

  data1: any = [];
  updateOptions1: any;
  options1 = {
    title: {
      text: 'Chart'
    },
    tooltip: {
      trigger: 'axis',
      formatter: function (params) {
        //params = params[0];
        const date = new Date(params.name);
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log("PARAMETRY");
        console.log(params);
        return params;
        //return date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear() + ' : ' + params.value[1];
      },
      axisPointer: {
        animation: false
      }
    },
    xAxis: {
      type: 'time',
      splitLine: {
        show: false
      }
    },
    yAxis: {
      type: 'value',
      boundaryGap: [0, '100%'],
      splitLine: {
        show: false
      }
    },
    series: [{
      name: 'Sumulation Data',
      type: 'line',
      showSymbol: false,
      hoverAnimation: false,
      data: this.data1
    }]
  };
  private now = new Date(2017, 9, 3);
  private value = Math.random() * 1000;
  private randomDataInterval;

//
  ionViewWillEnter() {


    // this.randomDataInterval = setInterval(() => {
    //   for (let i = 0; i < 5; i++) {
    //     this.data1.shift();
    //     this.data1.push(this.randomData());
    //   }

    //   this.updateOptions1 = {
    //     series: [{
    //       data: this.data1
    //     }]
    //   };
    // }, 1000);
  }
//
  ionViewWillLeave() {
    clearInterval(this.randomDataInterval);
  }

  rates1 = []
  rates2 = []
private dosome(d: string, v: number): object{

  // let parameters = new Map<string, string>();
  // Object.keys(this.rates).forEach(key => {
  //   console.log(key);
  //   console.log(this.rates[key].PLN);
  //   // this.data1.push(key,rates[key].PLN);
  //   // this.data1.push({
  //   //   name: key,
  //   //   value: [rates[key].PLN]
  //   // })
  //   this.now = new Date(+this.now + Tab2Page.oneDay);
  //   this.value = this.value + Math.random() * 21 - 10;
  //   this.data1.push( {
  //     name: this.now.toString(),
  //     value: [
  //       [this.now.getFullYear(), this.now.getMonth() + 1, this.now.getDate()].join('/'),
  //       Math.round(this.value)
  //     ]
  //   });
  //   console.log(this.data1[0]);
// });
        // for (let i = 0; i < 1000; i++) {
        // this.data1.push(this.randomData());

        this.now = new Date(+this.now + Tab2Page.oneDay);
        this.value = this.value + Math.random() * 21 - 10;
        // return {
        //   name: date.toString,
        //   value: 
        //     v
          
        // };

        console.log("TUUUUUUUU");
         console.log("JEDNO: "+[this.now.getFullYear(), this.now.getMonth() + 1, this.now.getDate()].join('/'));

        // let d2 = d.replace("-","/");

        console.log("DRUGIE: "+d)

        return {
          name: d.toString(),
          value: [
            d,
            Math.round(this.value)
            // date,
            // v
          ]
        };
        //this.data1.push( x);
      }





  private randomData(): object {

    this.now = new Date(+this.now + Tab2Page.oneDay);
    this.value = this.value + Math.random() * 21 - 10;
    return {
      name: this.now.toString(),
      value: [
        [this.now.getFullYear(), this.now.getMonth() + 1, this.now.getDate()].join('/'),
        Math.round(this.value)
      ]
    };
  }

}
